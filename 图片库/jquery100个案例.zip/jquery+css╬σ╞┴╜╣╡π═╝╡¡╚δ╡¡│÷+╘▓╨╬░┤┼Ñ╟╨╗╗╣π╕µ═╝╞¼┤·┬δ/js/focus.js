	$(function(){
		 $('#newsSlider').loopedSlider({
			//4��						   
		 	autoStart: 4000
			});
		$('.validate_Slider').loopedSlider({
			autoStart: 4000
			});
//Download by http://sc.xueit.com
	});